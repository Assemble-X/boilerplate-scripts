module.exports = {
    git: true,
    node: {
        install_modules: true,
        /* use npm or yarn while making project*/
    },
    ignore: [
        'node_modules',
        'yarn-error.log',
        'package-lock.json'
    ] /* adds in .gitignore */
}